<!DOCTYPE html>

<?php session_start() ?>

<?php include("database/ims_db_connect.php"); ?>

<html lang="en">

<head>
   
    <meta charset="UTF-8">
    
    <title>Login</title>
    
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/ims_style.css">
    <script src="js/bootstrap.js"></script>
    <script src="js/jquery.js"></script>
   
   <style>
   
       div.login
       {
           margin-top: 1000px;
           margin: auto;
           display: block;
           width: 50%;
       }
       
       img
       {
           height: 200px;
           width: 250px;
           border: red solid 2px;
           border-radius: 5px;
           margin: auto;
           display: block;
           margin-bottom: 100px;
           margin-top: 100px;
       }
       
   </style>
    
</head>

<body> 
       
    <img src="img/gw_logo.png" alt="logo"> 
      
    <div class="login">
       
    <div class="panel panel-alt">   
       
    <div>
    
        <!--
        
            - Page contains the login form
            - Inputs are checked against the table of authorized users
        
         -->
             
        <form action="Control/login_check.php" method='POST'>
            
            <label for="USERNAME">Username: </label>

            <input class="form-control" type="text" name="USERNAME">

            <br>

            <label for="USER_PASSWORD">Password: </label>

            <input class="form-control" type="password" name="USER_PASSWORD">
                 
            <br>
                       
             <div class="form-group">

                <input class="btn btn-default" type="reset" name="reset_fields" value="Reset"> 
                <input class="btn btn-default" type="submit" name="login" value="Submit"> 

            </div>  

            
        </form>
    
    </div> 

   </div>    
           
  </div>
            
</body>
    
</html>    