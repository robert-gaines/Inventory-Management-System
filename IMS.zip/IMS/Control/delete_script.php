<?php session_start() ?>

<?php include("../database/ims_db_connect.php"); ?>

<?php
 
 /*
 
    - Delete records per specified Asset # in the Table Display Page
    - Returns the user to the main delete page without a noticeable delay
 
 */

 if(isset($_GET['delete'])) 
    {
        $TGT_MINER = $_GET['delete'];

        $FACILITY = $_GET['facility'];

        $del_query = "DELETE FROM ".$FACILITY." WHERE ASSET = '{$TGT_MINER}' ";
     
        $tx_del_query = mysqli_query($connection, $del_query);
     
        if(!$tx_del_query)
        {
            //echo die().mysqli_error($connection);
        }
     
       header("Location: delete.php");
    }

?>