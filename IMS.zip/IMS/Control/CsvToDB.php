<!DOCTYPE html>

<html lang="en">

<head>
   
    <meta charset="UTF-8">
    
    <title>Update Script</title>
    
</head>

<body>
  
  <?php include("../Database/ims_db_connect.php"); ?>
   
   <?php
    
    
        $file = file('ephrata2.csv');
    
        $titles = $file[0];
    
        echo "<br/>";
    
        echo $titles."<br/>";
    
        for($i = 1; $i < count($file); $i++)
        {
            $temp = $file[$i];
            list($asset,$id,$type,$ip,$location,$building,$rack, $shelf, $position, $mac, $worker, $acct, $pdu, $serial, $netswitch, $sport, $status, $issues, $notes) = explode(',', $temp);
            //
            $miners[$i] = array('ASSET'=>$asset,'IDENTIFIER'=>$id,'TYPE'=>$type,'IP'=>$ip,'LOCATION'=>$location,'BUILDING'=>$building,'RACK'=>$rack,'SHELF'=>$shelf,'POSITION'=>$position,'MAC'=>$mac,'WORKER'=>$worker,'ACCOUNT'=>$acct,'PDU'=>$pdu,'SERIAL'=>$serial,'NETSWITCH'=>$netswitch,'SPORT'=>$sport,'STATUS'=>$status,'ISSUES'=>$issues,'NOTES'=>$notes);
            
            $query = "INSERT INTO MNR_EPHRATA_ONE(ASSET,IDENTIFIER,TYPE,IP,LOCATION,BUILDING,RACK,SHELF,POSITION,MAC,WORKER,ACCOUNT,PDU,SERIAL,NETSWITCH,SPORT,STATUS,ISSUES,NOTES)";
            $query .= "VALUES('{$asset}','{$id}','{$type}','{$ip}','{$location}','{$building}','{$rack}','{$shelf}','{$position}','{$mac}','{$worker}','{$acct}','{$pdu}','{$serial}','{$netswitch}','{$sport}','{$status}','{$issue}','{$notes}')";
            
            $tx_query = mysqli_query($connection, $query);
            
        }
    
        
        
        
    ?>
    
</body>

</html>