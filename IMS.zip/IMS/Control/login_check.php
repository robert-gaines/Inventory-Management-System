<?php session_start(); ?>

<?php include("../database/ims_db_connect.php"); ?>

<?php                                                                            
        if(isset($_POST['login']))
        {
            $uname = $_POST['USERNAME'];
            $pass = $_POST['USER_PASSWORD'];
        }
    
         $username = mysqli_real_escape_string($connection, $uname);
    
         $password = mysqli_real_escape_string($connection, $pass);
    
         $query = "SELECT * FROM IMS_USERS WHERE USERNAME = '{$uname}' ";
        
         $select_user_query = mysqli_query($connection, $query);
    
        if(!$select_user_query)
        {
            die("Query Failure".mysqli_error($connection));
        }
    
        while($row = mysqli_fetch_array($select_user_query))
        {
            $USER_NAME = $row['USERNAME'];
            $USER_PASSWORD = $row['USER_PASSWORD'];
        }
        
        $password = crypt($password, $USER_PASSWORD);
    
        if($username !== $USER_NAME && $password !== $USER_PASSWORD)
        {
            header("Location: ../index.php");
        }
        else if ($username === $USER_NAME && $password === $USER_PASSWORD)
        {
            header("Location: ../Model/main.php");
            $_SESSION['USERNAME'] = $USER_NAME;
        }
        else
        {
            header("Location: ../index.php");
        }
        
        
        
    
    ?>