<!DOCTYPE html>

<?php include("../database/ims_db_connect.php"); ?>
<?php include("../Model/nav.php"); ?>

<html lang="en">

<head>
   
    <meta charset="UTF-8">
    
    <title>Query Results</title>
    
    
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/ims_style.css">
    <script src="../js/bootstrap.js"></script>
    <script src="../js/jquery.js"></script>
   
    
    
</head>

<body>

    <h1>Search Results</h1> 
       
    <div class="wrapper">
         
    <div class="container">
        
        <div>
           
         <div class="overflow">
         
          <table class="table table-hover">
         
           <thead>
             <tr>
                 <th>Asset #</th>
                 <th>ID</th>
                 <th>Type</th>
                 <th>IP</th>
                 <th>Location</th>
                 <th>Building</th>
                 <th>Rack</th>
                 <th>Shelf</th>
                 <th>Position</th>
                 <th>MAC</th>
                 <th>Worker</th>
                 <th>Account</th>
                 <th>PDU</th>
                 <th>Serial</th>
                 <th>Netswitch</th>
                 <th>SPORT</th>
                 <th>Status</th>
                 <th>Issues</th>
                 <th>Notes</th>
             </tr>
           </thead>
         
         <tbody>
            
            <?php
                
                if(isset($_POST['submit']))
                {
                   $FACILITY = $_POST['facility'];    
                    
                   $search = $_POST['search'];
                    
                   /* Query the table according per Asset # */
                    
                   $query = "SELECT * FROM ".$FACILITY." WHERE ASSET LIKE '%$search' ";
                    
                   /*
                        - Echo for query debugging purposes
                        echo $query;
                        
                    */

                   $query_tx = mysqli_query($connection, $query);

                   $count = mysqli_num_rows($query_tx);

                   if(!$query_tx)
                   {
                       /* Optional Error Message for Debugging Purposes */
                       //die("Query Failed".mysqli_error($connection));
                   }

                   if($count == 0)
                   {
                       echo "<h3 style='color:red;'> No Result </h3>";
                   }
                   else
                   {
                       $query_tx = mysqli_query($connection, $query);

                        while($row = mysqli_fetch_assoc($query_tx))
                        {
                            $ASSET = $row['ASSET'];
                            $ID = $row['IDENTIFIER'];
                            $TYPE = $row['TYPE'];
                            $IP = $row['IP'];
                            $LOCATION = $row['LOCATION'];
                            $BUILDING = $row['BUILDING'];
                            $RACK = $row['RACK'];
                            $SHELF = $row['SHELF'];
                            $POSITION = $row['POSITION'];
                            $MAC = $row['MAC'];
                            $WORKER = $row['WORKER'];
                            $ACCOUNT = $row['ACCOUNT'];
                            $PDU = $row['PDU'];
                            $SERIAL = $row['SERIAL'];
                            $NETSWITCH = $row['NETSWITCH'];
                            $SPORT = $row['SPORT'];
                            $STATUS = $row['STATUS'];
                            $ISSUES = $row['ISSUES'];
                            $NOTES = $row['NOTES'];


                            echo "<tr>";
                            echo "<td>$ASSET</td>";
                            echo "<td>$ID</td>";
                            echo "<td>$TYPE</td>";
                            echo "<td>$IP</td>";
                            echo "<td>$LOCATION</td>";
                            echo "<td>$BUILDING</td>";
                            echo "<td>$RACK</td>";
                            echo "<td>$SHELF</td>";
                            echo "<td>$POSITION</td>";
                            echo "<td>$MAC</td>";
                            echo "<td>$WORKER</td>";
                            echo "<td>$ACCOUNT</td>";
                            echo "<td>$PDU</td>";
                            echo "<td>$SERIAL</td>";
                            echo "<td>$NETSWITCH</td>";
                            echo "<td>$SPORT</td>";
                            echo "<td>$STATUS</td>";
                            echo "<td>$ISSUES</td>";
                            echo "<td>$NOTES</td>";
                            echo "</tr>";
                        }
                       
                    }
                    
                }

             ?>
                    
         </tbody>  
          
        </table>
          
       </div>      
           
      </div>
        
    </div>    
           
  </div>
                      
</body>

</html>
