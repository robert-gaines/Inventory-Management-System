<!DOCTYPE html>

<?php include("../database/ims_db_connect.php"); ?>
<?php include("../Model/nav.php"); ?>


<html lang="en">

<head>
   
    <meta charset="UTF-8">
    
    <title>Edit</title>
    
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/ims_style.css">
    <script src="../js/bootstrap.js"></script>
    <script src="../js/jquery.js"></script>
    
</head>

<body>

    <h1>Edit</h1> 
       
    <div class="wrapper">
         
    <div class="container">
        
        <div class="panel panel-default col-lg-12">
            
            <form action="" method='POST'>
               
               <div class="form-group col-lg-12">
               
                <label for="facility">Select the facility: </label>
                
                    <select name="facility">
                         <option selected name="#" value="#">--Select the Facility--</option>
                         <option value="MNR_TNT_H">TNT-H</option>
                         <option value="MNR_TNT_A">TNT-A</option>
                         <option value="MNR_TNT_B">TNT-B</option>
                         <option value="MNR_TNT_C">TNT-C</option>
                         <option value="MNR_VL_1">Veedol(?)</option>
                         <option value="MNR_ROCK_ISLAND">Rock Island</option>
                         <option value="MNR_EPHRATA_ONE">Ephrata-One</option>
                         <option value="MNR_EPHRATA_TWO">Ephrata-Two</option>
                         <option value="MNR_MOSES_LAKE_ONE">Moses Lake - 1</option>
                         <option value="MNR_MOSES_LAKE_TWO">Moses Lake - 2</option>
                         <option value="MNR_MOSES_LAKE_THREE">Moses Lake - 3</option>
                         <option value="MNR_MOSES_LAKE_FOUR">Moses Lake - 4</option>
                         <option value="MNR_MOSES_LAKE_FIVE">Moses Lake - 5</option>
                         <option value="MNR_MOSES_LAKE_SIX">Moses Lake - 6</option>
                         <option value="MNR_MOSES_LAKE_DATA_CENTER">Moses Lake Data Center</option>
                         <option value="MNR_GEORGE">George</option>
                    </select>
                    
                    
                    <br>
                    <br>
                    <br>
                    
                    <div class="form-group">

                        <input class="btn btn-default" type="reset" name="reset_fields" value="Reset"> 
                        <input class="btn btn-default" type="submit" name="submit_miner" value="Submit"> 

                    </div>  
                
                </div>
                
               </form>
            
            </div> 
         
         <div class="overflow">
         
         <table class="table table-hover table-bordered">
         
         <thead>
            <tr>
                <th>Asset #</th>
                <th>ID</th>
                <th>Type</th>
                <th>IP</th>
                <th>Location</th>
                <th>Building</th>
                <th>Rack</th>
                <th>Shelf</th>
                <th>Position</th>
                <th>MAC</th>
                <th>Worker</th>
                <th>Account</th>
                <th>PDU</th>
                <th>Serial</th>
                <th>Netswitch</th>
                <th>SPORT</th>
                <th>Status</th>
                <th>Issues</th>
                <th>Notes</th>
                <th>Edit</th>
            </tr>
         </thead>
         
         <tbody>
         
         <div>
         
        <?php

            if(isset($_POST['facility']))
            {
                $FACILITY = $_POST['facility'];
            }
            else
            {
                echo "";
            }

            $query = "SELECT * FROM ".$FACILITY;

            $view_miners_query = mysqli_query($connection, $query);
             
            /* Retrieve and display all records from the specified table */ 

            while($row = mysqli_fetch_assoc($view_miners_query))
            {
                $ASSET = $row['ASSET'];
                $ID = $row['IDENTIFIER'];
                $TYPE = $row['TYPE'];
                $IP = $row['IP'];
                $LOCATION = $row['LOCATION'];
                $BUILDING = $row['BUILDING'];
                $RACK = $row['RACK'];
                $SHELF = $row['SHELF'];
                $POSITION = $row['POSITION'];
                $MAC = $row['MAC'];
                $WORKER = $row['WORKER'];
                $ACCOUNT = $row['ACCOUNT'];
                $PDU = $row['PDU'];
                $SERIAL = $row['SERIAL'];
                $NETSWITCH = $row['NETSWITCH'];
                $SPORT = $row['SPORT'];
                $STATUS = $row['STATUS'];
                $ISSUE = $row['ISSUE'];
                $NOTES = $row['NOTES'];

                /* 
                
                    - Note the edit column
                    - Selecting the edit icon redirects the user
                      to the edit form on an alternate page
                
                */

                echo "<tr>";
                echo "<td>$ASSET</td>";
                echo "<td>$ID</td>";
                echo "<td>$TYPE</td>";
                echo "<td>$IP</td>";
                echo "<td>$LOCATION</td>";
                echo "<td>$BUILDING</td>";
                echo "<td>$RACK</td>";
                echo "<td>$SHELF</td>";
                echo "<td>$POSITION</td>";
                echo "<td>$MAC</td>";
                echo "<td>$WORKER</td>";
                echo "<td>$ACCOUNT</td>";
                echo "<td>$PDU</td>";
                echo "<td>$SERIAL</td>";
                echo "<td>$NETSWITCH</td>";
                echo "<td>$SPORT</td>";
                echo "<td>$STATUS</td>";
                echo "<td>$ISSUE</td>";
                echo "<td>$NOTES</td>";
                echo "<td><a href='edit_script.php?edit={$ASSET}&facility={$FACILITY}'><button class='btn btn-warning'>Edit</button></a></td>";
                echo "</tr>";
            }
             
            /* Option Error Message for Debugging */ 
             
            if(!$view_miners_query)
            {
                //die("<h5 class='mysql_error'>Miner View Query Failed</h5>".mysqli_error($connection));
            }


         ?>
         
         </div>
         
         </tbody>  
          
         </table>
          
        </div>
           
      </div>
        
    </div>    
            
</body>

</html>