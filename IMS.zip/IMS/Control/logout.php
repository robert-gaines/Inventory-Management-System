<!DOCTYPE html>

<?php include("../database/ims_db_connect.php"); ?>

<html lang="en">

<head>
   
    <meta charset="UTF-8">
    
    <title></title>
    
</head>

<body>
    
    <?php session_start(); ?>
     
    <?php                                                                            
        $_SESSION['USERNAME'] = null;
        $_SESSION['USER_PASSWORD'] = null;
        header("Location: ../index.php")
    
    ?>
    
</body>

</html>