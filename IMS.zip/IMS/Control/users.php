<!DOCTYPE html>

<?php session_start() ?>

<?php include("../database/ims_db_connect.php"); ?>

<?php include("../Model/nav.php"); ?>

<html lang="en">

<head>
   
    <meta charset="UTF-8">
    
    <title>User Script</title>
   
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/ims_style.css">
    <script src="../js/bootstrap.js"></script>
    <script src="../js/jquery.js"></script>
      
</head>

<body>
 
   <!-- Form permits the addition of another user -->
  
   <div class="wrapper">
         
    <div class="container">
        
        <div class="panel panel-default col-lg-12">
            
          <form action="" method='POST'>
               
           <div class="form-group col-lg-12">
                
            <label for="USERNAME">Enter the Username: </label>

              <input class="form-control" type="text" name="USERNAME">

               <br>
                
                <label for="USER_PASSWORD">Enter the Password: </label>
                
                 <input class="form-control" type="password" name="USER_PASSWORD">
                
                 <br><br>
                
                 <div class="form-group">

                 <input class="btn btn-default" type="reset" name="reset_fields" value="Reset"> 
                 
                 <input class="btn btn-default" type="submit" name="add_user" value="Submit"> 

                 </div>  
                
                </div>
                
               </form>
            
            </div>
            
        </div>
        
    </div>     
   
   <?php
    
    error_reporting(~E_ALL);

    if(isset($_POST['add_user']))
    {
        $USER_ID = '';
        $USERNAME = $_POST['USERNAME'];
        $USER_PASSWORD = $_POST['USER_PASSWORD'];
        $MIN = 1;
        $MAX = 1000;
        $RAND_SALT = mt_rand($MIN, $MAX);
        $USER_PASSWORD = crypt($USER_PASSWORD, $RAND_SALT);

        $query = "INSERT INTO IMS_USERS(USER_ID, USERNAME, USER_PASSWORD, RAND_SALT)";

        $query .= "VALUES('{$USER_ID}','{$USERNAME}', '{$USER_PASSWORD}', '{$RAND_SALT}' )";

        $add_user_query = mysqli_query($connection, $query);

        if(!$add_user_query)
        {
            die("User Addition Failed".mysqli_error($connection));
        }
    }
    else
    {
        echo "";
    }
    
?>
    
</body>

</html>