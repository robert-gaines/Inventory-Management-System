<!DOCTYPE html>

<?php include("../database/ims_db_connect.php"); ?>
<?php include("../Model/nav.php"); ?>
<?php session_start() ?>

<html lang="en">

<head>
   
    <meta charset="UTF-8">
    
    <title>Update</title>
    
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/ims_style.css">
    <script src="../js/bootstrap.js"></script>
    <script src="../js/jquery.js"></script>
   
    
</head>

<body>

    <h1>Update</h1> 
       
    <div class="wrapper">
         
    <div class="container">
        
        <div class="panel panel-default col-lg-12">
            
            <form action="" method='POST'>
               
               <div class="form-group col-lg-12">
                
            <label for="facility"> Facility: </label>    
                
            <select name="facility">
                 <option selected name='#'>--Select the Facility--</option>
                 <option value="MNR_TNT_H">TNT-H</option>
                 <option value="MNR_TNT_A">TNT-A</option>
                 <option value="MNR_TNT_B">TNT-B</option>
                 <option value="MNR_TNT_C">TNT-C</option>
                 <option value="MNR_VL_1">Veedol(?)</option>
                 <option value="MNR_ROCK_ISLAND">Rock Island</option>
                 <option value="MNR_EPHRATA_ONE">Ephrata-One</option>
                 <option value="MNR_EPHRATA_TWO">Ephrata-Two</option>
                 <option value="MNR_MOSES_LAKE_ONE">Moses Lake - 1</option>
                 <option value="MNR_MOSES_LAKE_TWO">Moses Lake - 2</option>
                 <option value="MNR_MOSES_LAKE_THREE">Moses Lake - 3</option>
                 <option value="MNR_MOSES_LAKE_FOUR">Moses Lake - 4</option>
                 <option value="MNR_MOSES_LAKE_FIVE">Moses Lake - 5</option>
                 <option value="MNR_MOSES_LAKE_SIX">Moses Lake - 6</option>
                 <option value="MNR_MOSES_LAKE_DATA_CENTER">Moses Lake Data Center</option>
                 <option value="MNR_GEORGE">George</option>
            </select>
                
                <br>
                <br>
                <br>
                
                <label for="ASSET">Enter the Asset Tag#: </label>
                 <input class="form-control" type="text" name="ASSET">
                <br>
                 <label for="IDENTIFIER">Enter the ID: </label>
                <br>
                  <input class="form-control" type="text" name="IDENTIFIER">
                <br>
                 <label for="TYPE">Enter the Type: </label>
                <br>
                 <input class="form-control" type="text" name="TYPE">
                <br>
                 <label for="IP"> Enter the IP: </label>
                <br>
                 <input class="form-control" type="text" name="IP">
                <br> 
                 <label for="LOCATION"> Enter the Location: </label>
                <br>
                 <input class="form-control" type="text" name="LOCATION">
                <br>
                 <label for="BUILDING"> Enter the Building: </label>
                <br>
                 <input class="form-control" type="text" name="BUILDING">
                <br>
                 <label for="RACK"> Enter the Rack: </label>
                <br>
                 <input class="form-control" type="text" name="RACK">
                <br>
                 <label for="SHELF"> Enter the Shelf: </label>
                <br>
                 <input class="form-control" type="text" name="SHELF">
                <br>
                 <label for="POSITION"> Enter the Position: </label>
                <br>
                 <input class="form-control" type="text" name="POSITION">
                <br>
                 <label for="MAC"> Enter the MAC Address: </label>
                <br>
                 <input class="form-control" type="text" name="MAC">
                <br>
                 <label for="WORKER"> Enter the Worker ID: </label>
                <br>
                 <input class="form-control" type="text" name="WORKER">
                <br>
                 <label for="ACCOUNT"> Enter the Account ID: </label>
                <br>
                 <input class="form-control" type="text" name="ACCOUNT">
                <br>
                 <label for="PDU"> Enter the PDU: </label>
                <br>
                 <input class="form-control" type="text" name="PDU">
                <br>
                 <label for="SERIAL"> Enter the Serial#: </label>
                <br>
                 <input class="form-control" type="text" name="SERIAL">
                <br>
                 <label for="NETSWITCH"> Enter the Switch ID: </label>
                <br>
                 <input class="form-control" type="text" name="NETSWITCH">
                <br>
                 <label for="SPORT"> Enter the Source Port: </label>
                <br>
                 <input class="form-control" type="text" name="SPORT">
                <br>
                 <label for="STATUS"> Enter the Status: </label>
                <br>
                 <input class="form-control" type="text" name="STATUS">
                <br>
                  <label for="ISSUES"> Enter any issues: </label>
                <br>
                 <input class="form-control" type="text" name="ISSUES">
                <br>
                <label for="NOTES"> Enter any Notes: </label>
                <br>
                 <input class="form-control" type="text" name="NOTES">
                <br>
                
                <!-- Submit -->  
                  
                <div class="form-group">

                    <input class="btn btn-default" type="reset" name="reset_fields" value="Reset"> 
                    <input class="btn btn-default" type="submit" name="submit_miner" value="Submit"> 

                </div>  
                
            </div>
                
           </form>
             
          </div>
            
         </div>
        
        </div>     
         
    <?php
    
        /* Parse Form Data */ 
    
        $FACILITY = $_POST['facility'];
    
        if(isset($_POST['submit_miner']))
        {
           $ASSET = $_POST['ASSET'];
           $ID = $_POST['IDENTIFIER'];
           $TYPE = $_POST['TYPE'];
           $IP = $_POST['IP'];
           $LOCATION = $_POST['LOCATION'];
           $BUILDING = $_POST['BUILDING'];
           $RACK = $_POST['RACK'];
           $SHELF = $_POST['SHELF'];
           $POSITION = $_POST['POSITION'];
           $MAC = $_POST['MAC'];
           $WORKER = $_POST['WORKER'];
           $ACCOUNT = $_POST['ACCOUNT'];
           $PDU = $_POST['PDU'];
           $SERIAL = $_POST['SERIAL'];
           $NETSWITCH = $_POST['NETSWITCH'];
           $SPORT = $_POST['SPORT'];
           $STATUS = $_POST['STATUS'];
           $ISSUES = $_POST['ISSUES'];
           $NOTES = $_POST['NOTES'];
        }
        else
        {
            //echo "[!] Update Failed ";
        }
    
        /* Update by Facility */
    
        $query = "INSERT INTO ".$FACILITY."(ASSET,IDENTIFIER,TYPE,IP,LOCATION,BUILDING,RACK,SHELF,POSITION,MAC,WORKER,ACCOUNT,PDU,SERIAL,NETSWITCH,SPORT,STATUS,ISSUES,NOTES)";
        $query .= "VALUES('{$ASSET}','{$ID}','{$TYPE}','{$IP}','{$LOCATION}','{$BUILDING}','{$RACK}','{$SHELF}','{$POSITION}','{$MAC}','{$WORKER}','{$ACCT}','{$PDU}','{$SERIAL}','{$NETSWITCH}','{$SPORT}','{$STATUS}','{$ISSUES}','{$NOTES}')";
            
        $add_miner_query = mysqli_query($connection, $query);
                
        if(!$add_miner_query)
        {
            //die("Miner Addition Failed".mysqli_error($connection));
        }

        
     ?>
            
</body>

</html>