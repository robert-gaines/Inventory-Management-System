<!DOCTYPE html>

<?php include("../database/ims_db_connect.php"); ?>
<?php include("../Model/nav.php"); ?>
<?php session_start() ?>

<html lang="en">

<head>
   
    <meta charset="UTF-8">
    
    <title>Editor</title>
    
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/ims_style.css">
    <script src="../js/bootstrap.js"></script>
    <script src="../js/jquery.js"></script>
    
</head>

<?php
    
    $FACILITY = $_GET['facility'];
    
    $MINER_QUERY_ID = $_GET['edit'];

    $edit_query = "SELECT * FROM ".$FACILITY." WHERE ASSET = '{$MINER_QUERY_ID}' ";
          
    $tx_edit_query = mysqli_query($connection, $edit_query);
          
    while($row = mysqli_fetch_assoc($tx_edit_query))
      {
        $ASSET = $row['ASSET'];
        $ID = $row['IDENTIFIER'];
        $TYPE = $row['TYPE'];
        $IP = $row['IP'];
        $LOCATION = $row['LOCATION'];
        $BUILDING = $row['BUILDING'];
        $RACK = $row['RACK'];
        $SHELF = $row['SHELF'];
        $POSITION = $row['POSITION'];
        $MAC = $row['MAC'];
        $WORKER = $row['WORKER'];
        $ACCOUNT = $row['ACCOUNT'];
        $PDU = $row['PDU'];
        $SERIAL = $row['SERIAL'];
        $NETSWITCH = $row['NETSWITCH'];
        $SPORT = $row['SPORT'];
        $STATUS = $row['STATUS'];
        $ISSUES = $row['ISSUES'];
        $NOTES = $row['NOTES'];
      }
    
 ?>

<body>

<h1>Edit Form</h1> 

<div class="wrapper">

 <div class="container">

  <div class="panel panel-default col-lg-12">

   <form action="" method='POST'>

    <div class="form-group col-lg-12">

     <label for="facility">Current Fßacility: </label>

      <select name="facility" id="facility" value="<?php echo $FACILITY; ?>">
       
       <option selected><?php echo $FACILITY; ?></option>
       <option value="MNR_TNT_H">TNT-H</option>
       <option value="MNR_TNT_A">TNT-A</option>
       <option value="MNR_TNT_B">TNT-B</option>
       <option value="MNR_TNT_C">TNT-C</option>
       <option value="MNR_VL_1">Veedol(?)</option>
       <option value="MNR_ROCK_ISLAND">Rock Island</option>
       <option value="MNR_EPHRATA_ONE">Ephrata-One</option>
       <option value="MNR_EPHRATA_TWO">Ephrata-Two</option>
       <option value="MNR_MOSES_LAKE_ONE">Moses Lake - 1</option>
       <option value="MNR_MOSES_LAKE_TWO">Moses Lake - 2</option>
       <option value="MNR_MOSES_LAKE_THREE">Moses Lake - 3</option>
       <option value="MNR_MOSES_LAKE_FOUR">Moses Lake - 4</option>
       <option value="MNR_MOSES_LAKE_FIVE">Moses Lake - 5</option>
       <option value="MNR_MOSES_LAKE_SIX">Moses Lake - 6</option>
       <option value="MNR_MOSES_LAKE_DATA_CENTER">Moses Lake Data Center</option>
       <option value="MNR_GEORGE">George</option>

      </select>

      <br>
      <br>
      <br>
      
      <!-- Populate HTML Form with Existing Values -->
      
        <label for="ASSET">Enter the Asset Tag#: </label>
         <input class="form-control" type="text" name="ASSET" value="<?php echo $ASSET; ?>">
        <br>
         <label for="IDENTIFIER">Enter the ID: </label>
        <br>
          <input class="form-control" type="text" name="IDENTIFIER" value="<?php echo $ID; ?>">
        <br>
         <label for="TYPE">Enter the Type: </label>
        <br>
         <input class="form-control" type="text" name="TYPE" value="<?php echo $TYPE; ?>">
        <br>
         <label for="IP"> Enter the IP: </label>
        <br>
         <input class="form-control" type="text" name="IP" value="<?php echo $IP; ?>">
        <br> 
         <label for="LOCATION"> Enter the Location: </label>
        <br>
         <input class="form-control" type="text" name="LOCATION" value="<?php echo $LOCATION; ?>">
        <br>
         <label for="BUILDING"> Enter the Building: </label>
        <br>
         <input class="form-control" type="text" name="BUILDING" value="<?php echo $BUILDING; ?>">
        <br>
         <label for="RACK"> Enter the Rack: </label>
        <br>
         <input class="form-control" type="text" name="RACK" value="<?php echo $RACK; ?>">
        <br>
         <label for="SHELF"> Enter the Shelf: </label>
        <br>
         <input class="form-control" type="text" name="SHELF" value="<?php echo $SHELF; ?>">
        <br>
         <label for="POSITION"> Enter the Position: </label>
        <br>
         <input class="form-control" type="text" name="POSITION" value="<?php echo $POSITION; ?>">
        <br>
         <label for="MAC"> Enter the MAC Address: </label>
        <br>
         <input class="form-control" type="text" name="MAC" value="<?php echo $MAC; ?>">
        <br>
         <label for="WORKER"> Enter the Worker ID: </label>
        <br>
         <input class="form-control" type="text" name="WORKER" value="<?php echo $WORKER; ?>">
        <br>
         <label for="ACCOUNT"> Enter the Account ID: </label>
        <br>
         <input class="form-control" type="text" name="ACCOUNT" value="<?php echo $ACCOUNT; ?>">
        <br>
         <label for="PDU"> Enter the PDU: </label>
        <br>
         <input class="form-control" type="text" name="PDU" value="<?php echo $PDU; ?>">
        <br>
         <label for="SERIAL"> Enter the Serial#: </label>
        <br>
         <input class="form-control" type="text" name="SERIAL" value="<?php echo $SERIAL; ?>">
        <br>
         <label for="NETSWITCH"> Enter the Switch ID: </label>
        <br>
         <input class="form-control" type="text" name="NETSWITCH" value="<?php echo $NETSWITCH; ?>">
        <br>
         <label for="SPORT"> Enter the Source Port: </label>
        <br>
         <input class="form-control" type="text" name="SPORT" value="<?php echo $SPORT; ?>">
        <br>
         <label for="STATUS"> Enter the Status: </label>
        <br>
         <input class="form-control" type="text" name="STATUS" value="<?php echo $STATUS; ?>">
        <br>
          <label for="ISSUES"> Enter any issues: </label>
        <br>
         <input class="form-control" type="text" name="ISSUES" value="<?php echo $ISSUES; ?>">
        <br>
        <label for="NOTES"> Enter any Notes: </label>
        <br>
         <input class="form-control" type="text" name="NOTES" value="<?php echo $NOTES; ?>">
        <br>
        
       <br>
        
       <!-- Submit modified values to the associated table -->

        <div class="form-group">

            <input class="btn btn-default" type="reset" name="reset_fields" value="Reset"> 
            <input class="btn btn-default" type="submit" name="update_miner" value="Submit"> 

        </div>  

    </div>

   </form>
   
   <?php
      
     $FACILITY = $_POST['facility'];
    
     if(isset($_POST['update_miner']))
     {
        $ASSET = $_POST['ASSET'];
        $ID = $_POST['IDENTIFIER'];
        $TYPE = $_POST['TYPE'];
        $IP = $_POST['IP'];
        $LOCATION = $_POST['LOCATION'];
        $BUILDING = $_POST['BUILDING'];
        $RACK = $_POST['RACK'];
        $SHELF = $_POST['SHELF'];
        $POSITION = $_POST['POSITION'];
        $MAC = $_POST['MAC'];
        $WORKER = $_POST['WORKER'];
        $ACCOUNT = $_POST['ACCOUNT'];
        $PDU = $_POST['PDU'];
        $SERIAL = $_POST['SERIAL'];
        $NETSWITCH = $_POST['NETSWITCH'];
        $SPORT = $_POST['SPORT'];
        $STATUS = $_POST['STATUS'];
        $ISSUES = $_POST['ISSUES'];
        $NOTES = $_POST['NOTES'];
     }
     
         
     $edit_query = "UPDATE ".$FACILITY." SET ";
     $edit_query.= "ASSET = '{$ASSET}', ";  
     $edit_query.= "IDENTIFIER = '{$ID}', ";
     $edit_query.= "TYPE = '{$TYPE}', ";
     $edit_query.= "IP = '{$IP}', ";
     $edit_query.= "LOCATION = '{$LOCATION}', ";
     $edit_query.= "BUILDING = '{$BUILDING}', ";
     $edit_query.= "RACK = '{$RACK}', ";
     $edit_query.= "SHELF = '{$SHELF}', ";
     $edit_query.= "POSITION = '{$POSITION}', ";
     $edit_query.= "MAC = '{$MAC}', ";
     $edit_query.= "WORKER = '{$WORKER}', ";
     $edit_query.= "ACCOUNT = '{$ACCOUNT}', ";
     $edit_query.= "PDU = '{$PDU}', ";
     $edit_query.= "SERIAL = '{$SERIAL}', ";
     $edit_wuery.= "NETSWITCH = '{$NETSWITCH}', ";
     $edit_query.= "SPORT = '{$SPORT}', ";
     $edit_query.= "STATUS = '{$STATUS}', ";
     $edit_query.= "ISSUES = '{$ISSUES}', ";
     $edit_query.= "NOTES = '{$NOTES}' ";
     $edit_query.= "WHERE ASSET = '{$MINER_QUERY_ID}'";
      //  
     $tx_edit_query = mysqli_query($connection, $edit_query);
          //
     if(!$tx_edit_query)
     {
       //die("MINER DATA UPDATE FAILED".mysqli_error($connection));
     }
      
     /* Return the user to the Primary Edit Page */  
      
     header("Location: edit.php");

      
    ?>

  </div>

</div>

</div>     
            
</body>

</html>