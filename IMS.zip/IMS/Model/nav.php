<!DOCTYPE html>

<html lang="en">

<head>
   
    <meta charset="UTF-8">
    
    <title></title>
       
        <link rel="stylesheet" href="../css/bootstrap.css">
        <script src="../js/bootstrap.js"></script>
        <script src="../js/jquery.js"></script>
        
        <style>
        
            .nav-container
            {
                margin-bottom: 100px;
            }
            
        </style>
        
</head>

<body>
   
<div class="nav-container">  
    
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
 <div class="container">
  <div class="navbar-header">
   <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
   <span class="sr-only">#</span>
   <span class="icon-bar"></span>
   <span class="icon-bar"></span>
   <span class="icon-bar"></span>
   </button>
    <a class="navbar-brand" href="../Model/main.php">Main</a> 
   </div>
   <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
    <ul class="nav navbar-nav">
     <li>
      <a href="../View/view.php">View</a>
     </li>
     <li>
      <li>
       <a class = "dropdown-toggle" data-toggle="dropdown" href="#">Update
        <span class="caret"></span></a>
         <ul class = "dropdown-menu" style="background-color: darkgray;">
          <li><a href="../database/DatabaseUpdate.php"> Bulk Update </a></li>
          <li><a href="../Control/update.php"> Single Entry </a></li>
          <li><a href="../Control/users.php"> Add User </a></li>
         </ul>
       </li>
       <li>
        <a href="../Control/edit.php">Edit</a>
       </li>
       <li>
        <a href="../Control/delete.php">Delete</a>
       </li>
       <li>
        <a href="../Control/logout.php">Logout</a>
       </li>
     </ul>
    </div>
   </div>
</nav>
    
</div>
     
</body>

</html>