<!DOCTYPE html>

<html lang="en">

<head>
   
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <title>IMS Application</title>
    
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/ims_style.css">
    <script src="../js/bootstrap.js"></script>
    <script src="../js/jquery.js"></script>
    
    <style>
    
        .menu
        {
            margin: 0 auto;
            margin-top: 20px;
            margin-bottom: 20px;
            border-radius: 5px;
            width: 25%;
        }
        
    </style>
   
</head>

<body>
    
    <!-- 
    
     - Portal Landing Page
     - Orients user attention to primary IMS functions
    
     -->

    <h1>IMS Application</h1> 
       
         <div class="wrapper">
         
         <div class="panel panel-alt">
         
          <table class='menu'>
          <tr>
            <td>
              <button class="btn btn-default col-xs-12">
               <a href="../View/view.php">View</a>
              </button>
            </td>       
           </tr>
           <tr>
            <td>
              <button class="btn btn-default col-xs-12">
               <a href="../Control/update.php">Update</a>
              </button>
            </td>       
           </tr>
           <tr>
            <td>        
             <button class="btn btn-default col-xs-12">
               <a href="../Control/edit.php"> Edit </a>
             </button>
            </td>
           </tr>
           <tr> 
            <td>   
              <button class="btn btn-default col-xs-12">
               <a href="../Control/delete.php">Delete</a>
              </button>
            </td>
           </tr>
           <tr>
            <td>    
             <button class="btn btn-default col-xs-12">
               <a href="../Control/logout.php">Logout</a>
             </button>
            </td>
           </tr>       
          </table>
          
          </div>
        
         </div>
   
    <?php
    
        
    
     ?>
            
</body>

</html>