<!DOCTYPE html>

<?php include("../Database/ims_db_connect.php"); ?>
<?php include("../Model/nav.php"); ?>

<html lang="en">

<head>
   
    <meta charset="UTF-8">
    
    <title>Bulk Update</title>
    
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/ims_style.css">
    <script src="../js/bootstrap.js"></script>
    <script src="../js/jquery.js"></script>
    
    
    <style>
    
        .update-text
        {
            color: darkred;
            margin-top: 100px;
        }
        
        .file-upload
        {
            background-color: darkgray;
            border-radius: 2px;
            border: red 2px solid;
            color: black;
        }
        
    </style>
    
</head>

    <body>

       <div class="wrapper">
           
           <div class="container">
               
               <div class='update-text'>
                   
                   <form action="" method='POST' enctype='multipart/form-data'>
                       
                       <div class="form-group">
                       
                         <!-- 
                          
                             - Select the Facility
                             - Facility value is associated with the DB Table
                          
                           -->
                          
                           <label for="db_select">Table</label>
                           
                           <select name="db_select">
                             <option value="#" name="#" selected>--Select Table--</option>
                             <option value="MNR_TNT_H">TNT-H</option>
                             <option value="MNR_TNT_A">TNT-A</option>
                             <option value="MNR_TNT_B">TNT-B</option>
                             <option value="MNR_TNT_C">TNT-C</option>
                             <option value="MNR_VL_1">Veedol(?)</option>
                             <option value="MNR_ROCK_ISLAND">Rock Island</option>
                             <option value="MNR_EPHRATA_ONE">Ephrata-One</option>
                             <option value="MNR_EPHRATA_TWO">Ephrata-Two</option>
                             <option value="MNR_MOSES_LAKE_ONE">Moses Lake - 1</option>
                             <option value="MNR_MOSES_LAKE_TWO">Moses Lake - 2</option>
                             <option value="MNR_MOSES_LAKE_THREE">Moses Lake - 3</option>
                             <option value="MNR_MOSES_LAKE_FOUR">Moses Lake - 4</option>
                             <option value="MNR_MOSES_LAKE_FIVE">Moses Lake - 5</option>
                             <option value="MNR_MOSES_LAKE_SIX">Moses Lake - 6</option>
                             <option value="MNR_MOSES_LAKE_DATA_CENTER">Moses Lake Data Center</option>
                             <option value="MNR_GEORGE">George</option>
                           </select>
                       
                           <br>
                           <br>
                           <br>
                           
                           <input class="btn btn-default" type="Submit" name="truncate" value="Purge Database">
                           
                           <br>
                           <br>
                           <br>
                       
                       <!-- File Upload Form -->
                       <!-- Corresponding Script Parses .CSV Format -->
                       
                       <div class="file-upload">
                       
                       <br>
                       
                        <label for="file">Input File:</label>

                           <input class="form-group" type="file" name='inv_file' style='margin: 0 auto;'>

                        <br>  
                          
                           </div>

                           <br>

                        <div class="form-group">

                           <input class="btn btn-default" type="reset" name="reset_fields" value="Reset"> 

                           <input class="btn btn-default" type="submit" name="" value="Submit"> 

                        </div> 
                        
                       </div> 

                   </form>
                   
                   <?php
                   
                        //echo $_FILES['inv_file']['tmp_name'];
                   
                        $tmp = $_FILES['inv_file']['tmp_name'];
                   
                        $handle = file($tmp);
                   
                        $db = $_POST['db_select'];
                   
                        for($i = 1; $i < count($handle); $i++)
                        {
                            $temp = $handle[$i];
                            list($asset,$id,$type,$ip,$location,$building,$rack, $shelf, $position, $mac, $worker, $acct, $pdu, $serial, $netswitch, $sport, $status, $issues, $notes) = explode(',', $temp);
                            //
                            $miners[$i] = array('ASSET'=>$asset,'IDENTIFIER'=>$id,'TYPE'=>$type,'IP'=>$ip,'LOCATION'=>$location,'BUILDING'=>$building,'RACK'=>$rack,'SHELF'=>$shelf,'POSITION'=>$position,'MAC'=>$mac,'WORKER'=>$worker,'ACCOUNT'=>$acct,'PDU'=>$pdu,'SERIAL'=>$serial,'NETSWITCH'=>$netswitch,'SPORT'=>$sport,'STATUS'=>$status,'ISSUES'=>$issues,'NOTES'=>$notes);

                            $query = "INSERT INTO ".$db."(ASSET,IDENTIFIER,TYPE,IP,LOCATION,BUILDING,RACK,SHELF,POSITION,MAC,WORKER,ACCOUNT,PDU,SERIAL,NETSWITCH,SPORT,STATUS,ISSUES,NOTES)";
                            $query .= "VALUES('{$asset}','{$id}','{$type}','{$ip}','{$location}','{$building}','{$rack}','{$shelf}','{$position}','{$mac}','{$worker}','{$acct}','{$pdu}','{$serial}','{$netswitch}','{$sport}','{$status}','{$issues}','{$notes}')";

                            $tx_query = mysqli_query($connection, $query);
                        }
                       
                    ?>
                    
                    <?php
                   
                        /*
                        
                        - Script Truncates a specified database table
                        - Option clears the existing content in preparation
                          for the introduction of new data
                        
                        */
                   
                        if(isset($_POST['truncate']) && isset($_POST['db_select']))
                        {
                            $db = $_POST['db_select'];
                            //
                            $truncate_query = "TRUNCATE TABLE ".$db;
                            //
                            $tx_truncate = mysqli_query($connection, $truncate_query);
                        }
                        else
                        {
                            echo "";
                        }
                   
                     ?>
                   
               </div>
               
           </div>
           
       </div>
   
    </body>

</html>
