<!DOCTYPE html>

<html lang="en">

<head>
   
    <meta charset="UTF-8">
    
</head>

<body>

<?php
    
error_reporting(~E_ALL);
    
/* Values Set for Testing, Change Prior to Implementation */    
    
$db['db_host'] = "localhost"; 
$db['db_user'] = "root";
$db['db_pass'] = "";
$db['db_name'] = "gigawatt_ims";
    
foreach($db as $key => $value)
{
    define(strtoupper($key), $value);
}

$connection = mysqli_connect(DB_HOST,
                             DB_USER,
                             DB_PASS, 
                             DB_NAME);
    
if($connection) {echo "";}
    
    
/*
    - For connectivity testing purposes -
    
    <h1 style='color: green;'> DB CONNECTED </h1>
*/
    
?>    
    
</body>

</html>